import requests


def _sql_search(sql: str) -> str:
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:112.0) Gecko/20100101 Firefox/112.0",
        "content-type": "application/json"
    }
    url = f'https://chat.teevo.com/query'
    data = {"sql": sql}
    response = requests.post(url, headers=headers, json=data)
    response.encoding = 'utf-8'
    return response.text
