import requests


def _load_schema() -> str:
    headers = {
        'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:112.0) Gecko/20100101 Firefox/112.0",
        'Authorization': 'Bearer 4b4580f50a7fa8259d20f23c2e5b9d8e1856827ff1a2c2fe73f79faa6d173f817ffc7a04455865e63dfe4ddf8c8b892e017052358da49b10df9d8637ea3e44543671cdf178d7e396661374d7033e027a933ca6bfc0e42bb283f119269e8a19272f1fc54c17da84c89da0891bbd7e37f3aa18de4e8a40f03ed4de2140d9f71065'
    }
    url = f'https://book.teevo.com/api/tables?populate=%2A&publicationState=preview'
    response = requests.get(url, headers=headers)
    response.encoding = 'utf-8'
    return response.text
